package config;

public class config {
    public static final String RUTA_BINARIO_PELICULAS = "src/resources/peliculas.dat";
    public static final String RUTA_CSV_PELICULAS = "src/resources/peliculas.csv";
}
